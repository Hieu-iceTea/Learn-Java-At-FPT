create view `current product list` as
select `northwind`.`products`.`ProductID` AS `ProductID`, `northwind`.`products`.`ProductName` AS `ProductName`
from `northwind`.`products`
where `northwind`.`products`.`Discontinued` = 0;

