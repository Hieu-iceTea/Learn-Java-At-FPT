create
    definer = root@localhost procedure sp_Employees_Update(IN AtEmployeeID int, IN AtLastName varchar(20),
                                                           IN AtFirstName varchar(10), IN AtTitle varchar(30),
                                                           IN AtTitleOfCourtesy varchar(25), IN AtBirthDate datetime,
                                                           IN AtHireDate datetime, IN AtAddress varchar(60),
                                                           IN AtCity varchar(15), IN AtRegion varchar(15),
                                                           IN AtPostalCode varchar(10), IN AtCountry varchar(15),
                                                           IN AtHomePhone varchar(24), IN AtExtension varchar(4),
                                                           IN AtPhoto longblob, IN AtNotes mediumtext,
                                                           IN AtReportsTo int, IN AtPhotoPath varchar(255))
BEGIN
Update Employees
	Set
		LastName = AtLastName,
		FirstName = AtFirstName,
		Title = AtTitle,
		TitleOfCourtesy = AtTitleOfCourtesy,
		BirthDate = AtBirthDate,
		HireDate = AtHireDate,
		Address = AtAddress,
		City = AtCity,
		Region = AtRegion,
		PostalCode = AtPostalCode,
		Country = AtCountry,
		HomePhone = AtHomePhone,
		Extension = AtExtension,
		Photo = AtPhoto,
		Notes = AtNotes,
		ReportsTo = AtReportsTo,
    PhotoPath = AtPhotoPath
	Where
		EmployeeID = AtEmployeeID;

END;

