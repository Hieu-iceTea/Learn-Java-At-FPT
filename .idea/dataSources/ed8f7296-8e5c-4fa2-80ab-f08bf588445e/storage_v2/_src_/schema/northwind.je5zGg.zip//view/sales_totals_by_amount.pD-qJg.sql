create definer = root@localhost view `sales totals by amount` as
select `order subtotals`.`Subtotal`          AS `SaleAmount`,
       `northwind`.`orders`.`OrderID`        AS `OrderID`,
       `northwind`.`customers`.`CompanyName` AS `CompanyName`,
       `northwind`.`orders`.`ShippedDate`    AS `ShippedDate`
from ((`northwind`.`customers` join `northwind`.`orders` on (`northwind`.`customers`.`CustomerID` =
                                                             `northwind`.`orders`.`CustomerID`))
         join `northwind`.`order subtotals` on (`northwind`.`orders`.`OrderID` = `order subtotals`.`OrderID`))
where `order subtotals`.`Subtotal` > 2500
  and `northwind`.`orders`.`ShippedDate` between '1997-01-01' and '1997-12-31';

