create view `summary of sales by year` as
select `northwind`.`orders`.`ShippedDate` AS `ShippedDate`,
       `northwind`.`orders`.`OrderID`     AS `OrderID`,
       `order subtotals`.`Subtotal`       AS `Subtotal`
from (`northwind`.`orders`
         join `northwind`.`order subtotals` on (`northwind`.`orders`.`OrderID` = `order subtotals`.`OrderID`))
where `northwind`.`orders`.`ShippedDate` is not null;

