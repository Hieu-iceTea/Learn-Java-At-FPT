create
    definer = root@localhost procedure SalesByCategory()
BEGIN

END;

