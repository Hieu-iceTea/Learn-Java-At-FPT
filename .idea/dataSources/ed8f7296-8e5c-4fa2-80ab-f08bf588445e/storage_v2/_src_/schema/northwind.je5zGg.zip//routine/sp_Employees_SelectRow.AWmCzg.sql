create
    definer = root@localhost procedure sp_Employees_SelectRow(IN AtEmployeeID int)
BEGIN
SELECT * FROM Employees Where EmployeeID = AtEmployeeID;

END;

